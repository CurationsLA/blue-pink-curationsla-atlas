Add generated favicon/app icons here:
- la-icon-16.png
- la-icon-32.png
- la-icon-180.png
- la-icon-192.png
- la-icon-512.png
- la-icon-maskable-512.png
(optional) favicon.ico